Logo após todo o projeto estar pronto:
Criar um banco para ele:

Passo a passo:

Fotos no repositório:
Aula-Integração Banco


Explicações: application.properties

spring.jpa.hibernate.ddl-auto=update

spring.datasource.url=jdbc:mysql://${MYSQL_HOST:localhost}:3306/carro_db
 --> (carro_db deve ter o mesmo nome do banco em que será armazenado)

spring.datasource.username=root 

spring.datasource.password=admin --> (senha | na escola: ifsp)

spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver 
(Passa o endereço de um pacote com a classe chamada driver 
--> adicionada no inicio do projeto)

#spring.jpa.show-sql: true
--> (Define se você quer que mostre as SQL geradas)

-- > none, update, create, create-drop : indica o que você quer fazer com o banco

-->Após tudo estar pronto:
Start em Application.java<--