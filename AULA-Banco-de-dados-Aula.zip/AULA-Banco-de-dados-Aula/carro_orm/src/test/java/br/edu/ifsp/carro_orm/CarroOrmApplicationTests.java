package br.edu.ifsp.carro_orm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarroOrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
