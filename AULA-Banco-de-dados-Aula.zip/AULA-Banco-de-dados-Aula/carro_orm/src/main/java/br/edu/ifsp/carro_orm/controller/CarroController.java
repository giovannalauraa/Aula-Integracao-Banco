package br.edu.ifsp.carro_orm.controller;

import java.util.List; // Está é a lista correta para se importar

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifsp.carro_orm.model.Carro;
import br.edu.ifsp.carro_orm.repository.CarroRepository;


@RestController
@CrossOrigin
public class CarroController {
    @Autowired //Notação do Spring para: CarroRepository carroRepository = new CarroRepository();
    CarroRepository carroRepository;

    //Utilizando alguns métodos do repositório - Slide 23
    @PostMapping("/carro")
    public void adicionaCarro( //Adicionando um carro
        @RequestBody Carro novoCarro
    ){
        carroRepository.save(novoCarro);

    }

    @GetMapping("/carro")
    public List<Carro> recuperaCarros(){
        return
        (List<Carro>) carroRepository.findAll();
    }
    
}
