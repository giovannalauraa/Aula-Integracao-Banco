package br.edu.ifsp.carro_orm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarroOrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarroOrmApplication.class, args);
	}

}
