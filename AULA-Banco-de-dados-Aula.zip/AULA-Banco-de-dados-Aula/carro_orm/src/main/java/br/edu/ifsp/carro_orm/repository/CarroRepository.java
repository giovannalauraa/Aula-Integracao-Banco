package br.edu.ifsp.carro_orm.repository;

import org.springframework.data.repository.CrudRepository; //Sempre importar o Crud

import br.edu.ifsp.carro_orm.model.Carro; //Sempre importar a classe

public interface CarroRepository extends  CrudRepository<Carro, Long> { // Note que é "public interface" e não "public class"
    
}
